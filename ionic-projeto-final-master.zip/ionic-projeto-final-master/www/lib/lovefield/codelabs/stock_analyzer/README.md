Lovefield + AngularJS demo using a database of historical stock data.

* Step 1: Install gulp (if you have not already), ```npm install -g gulp```
* Step 2: Install bower (if you have not already), ```npm install -g bower```
* Step 3: Pull dependencies in package.json, ```npm install .```
* Step 4: Pull dependencies in bower.json, ```bower install```
* Step 5: Start a local webserver, ```gulp debug```
* Step 6: Navigate to [http://localhost:8000/src/demo_angular.html](http://localhost:8000/src/demo_angular.html),
          and start making queries.
